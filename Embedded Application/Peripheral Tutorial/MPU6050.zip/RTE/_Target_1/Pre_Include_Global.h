
/*
 * Auto generated Run-Time-Environment Configuration File
 *      *** Do not modify ! ***
 *
 * Project: 'MPU6050' 
 * Target:  'Target 1' 
 */

#ifndef PRE_INCLUDE_GLOBAL_H
#define PRE_INCLUDE_GLOBAL_H

/* Keil::Device:STM32Cube HAL:Common:1.2.9 */
#define USE_HAL_DRIVER


#endif /* PRE_INCLUDE_GLOBAL_H */
