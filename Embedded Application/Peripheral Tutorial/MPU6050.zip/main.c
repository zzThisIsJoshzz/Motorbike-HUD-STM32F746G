#include <stdio.h>
#include <math.h>
#include <string.h>
#include <stdlib.h>
#include "stm32f7xx_hal.h"
#include "stm32f7xx_hal_gpio.h"
#include "GLCD_Config.h"
#include "Board_GLCD.h"


extern GLCD_FONT GLCD_Font_16x24;

TIM_HandleTypeDef htim2;
I2C_HandleTypeDef hi2c1;




#ifdef __RTX
		extern uint32_t os_time;
		uint32_t HAL_GetTick(void) {
			return os_time;
		}
#endif


void SystemClock_Config(void);
static void TIM2_Init(void);
static void GPIO_Init(void);
void Error_Handler(void);
static void I2C1_Init(void);

const float M_PI = 3.14159265358979323846;
		
#define MPU6050_ADDR (0x68 << 1) // 0xD0


#define SMPLRT_DIV_REG 0x19
#define GYRO_CONFIG_REG 0x1B
#define ACCEL_CONFIG_REG 0x1C
#define ACCEL_XOUT_H_REG 0x3B
#define TEMP_OUT_H_REG 0x41
#define GYRO_XOUT_H_REG 0x43
#define PWR_MGMT_1_REG 0x6B
#define WHO_AM_I_REG 0x75

int16_t Accel_X_RAW = 0;
int16_t Accel_Y_RAW = 0;
int16_t Accel_Z_RAW = 0;

int16_t Gyro_X_RAW = 0;
int16_t Gyro_Y_RAW = 0;
int16_t Gyro_Z_RAW = 0;

float pitch = 0;
float roll = 0;
float yaw = 0;

float Ax, Ay, Az, Gx, Gy, Gz;

int circX = 240;
int circY = 182;


void MPU6050_Init (void)
{
	uint8_t check;
	uint8_t Data;
	
	

	// check device ID WHO_AM_I

	HAL_I2C_Mem_Read (&hi2c1, MPU6050_ADDR,WHO_AM_I_REG,1, &check, 1, 1000);

	if (check == 104)  // 0x68 will be returned by the sensor if everything goes well
	{
		// power management register 0X6B we should write all 0's to wake the sensor up
		Data = 0;
		HAL_I2C_Mem_Write(&hi2c1, MPU6050_ADDR, PWR_MGMT_1_REG, 1,&Data, 1, 1000);

		// Set DATA RATE of 1KHz by writing SMPLRT_DIV register
		Data = 0x07;
		HAL_I2C_Mem_Write(&hi2c1, MPU6050_ADDR, SMPLRT_DIV_REG, 1, &Data, 1, 1000);

		// Set accelerometer configuration in ACCEL_CONFIG Register
		// XA_ST=0,YA_ST=0,ZA_ST=0, FS_SEL=0 -> � 2g
		Data = 0x00;
		HAL_I2C_Mem_Write(&hi2c1, MPU6050_ADDR, ACCEL_CONFIG_REG, 1, &Data, 1, 1000);

		// Set Gyroscopic configuration in GYRO_CONFIG Register
		// XG_ST=0,YG_ST=0,ZG_ST=0, FS_SEL=0 -> � 250 �/s
		Data = 0x00;
		HAL_I2C_Mem_Write(&hi2c1, MPU6050_ADDR, GYRO_CONFIG_REG, 1, &Data, 1, 1000);
	}

}


void MPU6050_Read_Accel (void)
{
	uint8_t Rec_Data[6];

	// Read 6 BYTES of data starting from ACCEL_XOUT_H register

	HAL_I2C_Mem_Read (&hi2c1, MPU6050_ADDR, ACCEL_XOUT_H_REG, 1, Rec_Data, 6, 1000);

	Accel_X_RAW = (int16_t)(Rec_Data[0] << 8 | Rec_Data [1]);
	Accel_Y_RAW = (int16_t)(Rec_Data[2] << 8 | Rec_Data [3]);
	Accel_Z_RAW = (int16_t)(Rec_Data[4] << 8 | Rec_Data [5]);

	/*** convert the RAW values into acceleration in 'g'
	     we have to divide according to the Full scale value set in FS_SEL
	     I have configured FS_SEL = 0. So I am dividing by 16384.0
	     for more details check ACCEL_CONFIG Register              ****/

	Ax = Accel_X_RAW/16384.0;
	Ay = Accel_Y_RAW/16384.0;
	Az = Accel_Z_RAW/16384.0;
}


void MPU6050_Read_Gyro (void)
{
	uint8_t Rec_Data[6];

	// Read 6 BYTES of data starting from GYRO_XOUT_H register

	HAL_I2C_Mem_Read (&hi2c1, MPU6050_ADDR, GYRO_XOUT_H_REG, 1, Rec_Data, 6, 1000);

	Gyro_X_RAW = (int16_t)(Rec_Data[0] << 8 | Rec_Data [1]);
	Gyro_Y_RAW = (int16_t)(Rec_Data[2] << 8 | Rec_Data [3]);
	Gyro_Z_RAW = (int16_t)(Rec_Data[4] << 8 | Rec_Data [5]);

	/*** convert the RAW values into dps (�/s)
	     we have to divide according to the Full scale value set in FS_SEL
	     I have configured FS_SEL = 0. So I am dividing by 131.0
	     for more details check GYRO_CONFIG Register              ****/

	Gx = Gyro_X_RAW/131.0;
	Gy = Gyro_Y_RAW/131.0;
	Gz = Gyro_Z_RAW/131.0;
}

void convertAcc (void){  //https://engineering.stackexchange.com/questions/3348/calculating-pitch-yaw-and-roll-from-mag-acc-and-gyro-data
	
	pitch = 180 * atan (Ax/sqrt(Ay*Ay + Az*Az))/M_PI;
	roll = 180 * atan (Ay/sqrt(Ax*Ax + Az*Az))/M_PI;
	yaw = 180 * atan (Az/sqrt(Ax*Ax + Az*Az))/M_PI;
	
	roll *= -1;
}




void drawDiagonalLineLow(int x0, int y0, int x1, int y1)
{
	int dx, dy, yi, D, x, y;
	dx = x1 - x0;
	dy = y1 - y0;
	yi = 1;
	if (dy < 0)
	{
		yi = -1;
		dy = -dy;
	}
	
	D = (2 * dy) - dx;
	y = y0;

	for (x = x0; x < x1; x++)
	{
		GLCD_DrawPixel(x, y);
		if (D > 0)
		{
			y = y + yi;
			D = D + (2 * (dy - dx));
		}
		else
		{
			D = D + 2*dy;
		}
	}
}

void drawDiagonalLineHigh(int x0, int y0, int x1, int y1)
{
	int dx, dy, xi, D, x, y;
	dx = x1 - x0;
	dy = y1 - y0;
	xi = 1;
	if (dx < 0)
	{
		xi = -1;
		dx = -dx;
	}
	D = (2 * dx) - dy;
	x = x0;

	for (y = y0; y < y1; y++)
	{
		GLCD_DrawPixel(x, y);
		if (D > 0)
		{
			x = x + xi;
			D = D + (2 * (dx - dy));
		}
		else
		{
			D = D + 2*dx;
		}
	}
}


void drawDiagonalLine(int x0, int y0, int x1, int y1)
{
	if (abs(y1 - y0) < abs(x1 - x0))
	{
		if (x0 > x1)
		{
			drawDiagonalLineLow(x1, y1, x0, y0);
		}
		else
		{
			drawDiagonalLineLow(x0, y0, x1, y1);
		}
	}
	else
	{
		if (y0 > y1)
		{
			drawDiagonalLineHigh(x1, y1, x0, y0);
		}
		else
		{
			drawDiagonalLineHigh(x0, y0, x1, y1);
		}
	}
}

float toRadians(float angle){
	return angle * ( M_PI / 180.0 );  
}

void getCircumferenceXY (int x0, int y0, int r, float angle){
	float xPos = 0;
	float yPos = 0;
	float radAngle = toRadians(angle) + (3*M_PI)/2; 
	
	xPos = r * (float)cos(radAngle) + x0;
  yPos = r * (float)sin(radAngle) + y0;
	
  circX = (int)xPos;
	circY = (int)yPos;
}



int main(void){
	
	char buf[5];
	
	HAL_Init(); //Init Hardware Abstraction Layer
	SystemClock_Config(); //Config Clocks
	SystemCoreClockUpdate();
	GPIO_Init();
	I2C1_Init();
	TIM2_Init();
	
	__HAL_RCC_TIM2_CLK_ENABLE();
	GLCD_Initialize(); //Init GLCD
	GLCD_ClearScreen();
	GLCD_SetFont(&GLCD_Font_16x24);
  GLCD_SetForegroundColor(GLCD_COLOR_PURPLE);
	drawDiagonalLine(240, 272, circX, circY);
	
	MPU6050_Init();


	
	HAL_Delay(2000);
	
	for(;;) {
	
		MPU6050_Read_Accel();
	  MPU6050_Read_Gyro();
		
		//sprintf(buf, "%.2f", Ax);
		//GLCD_DrawString((2*24), (1*24), buf);
		//sprintf(buf, "%.2f", Ay);
		//GLCD_DrawString((7*24), (1*24), buf);
		//sprintf(buf, "%.2f", Az);
		//GLCD_DrawString((12*24), (1*24), buf);
		
		//sprintf(buf, "%.2f", Gx);
		//GLCD_DrawString((2*24), (4*24), buf);
		//sprintf(buf, "%.2f", Gy);
		//GLCD_DrawString((7*24), (4*24), buf);
		//sprintf(buf, "%.2f", Gz);
		//GLCD_DrawString((12*24), (4*24), buf);
		
		
		
		convertAcc();
		GLCD_DrawString((2*24), (2*24), "pitch");
		sprintf(buf, "%.2f", pitch);
		GLCD_DrawString((2*24), (4*24), buf);
		
		GLCD_DrawString((7*24), (2*24), "roll");
		sprintf(buf, "%.2f", roll);
		GLCD_DrawString((7*24), (4*24), buf);
		
		GLCD_DrawString((12*24), (2*24), "yaw");
		sprintf(buf, "%.2f", yaw);
		GLCD_DrawString((12*24), (4*24), buf);
		
		GLCD_SetForegroundColor(GLCD_COLOR_WHITE);
		drawDiagonalLine(240, 272, circX, circY);
		getCircumferenceXY(240, 272, 90, roll);
		GLCD_SetForegroundColor(GLCD_COLOR_PURPLE);
		drawDiagonalLine(240, 272, circX, circY);
		
		HAL_Delay(250);
	}

}

		
		
		
		
		
		
		
void SystemClock_Config(void)
{
			RCC_OscInitTypeDef RCC_OscInitStruct;
			RCC_ClkInitTypeDef RCC_ClkInitStruct;
			/* Enable Power Control clock */
			__HAL_RCC_PWR_CLK_ENABLE();
			/* The voltage scaling allows optimizing the power
			consumption when the device is clocked below the
			maximum system frequency. */
			__HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);
			/* Enable HSE Oscillator and activate PLL
			with HSE as source */
			RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
			RCC_OscInitStruct.HSEState = RCC_HSE_ON;
			RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
			RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
			RCC_OscInitStruct.PLL.PLLM = 25;
			RCC_OscInitStruct.PLL.PLLN = 336;
			RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
			RCC_OscInitStruct.PLL.PLLQ = 7;
			HAL_RCC_OscConfig(&RCC_OscInitStruct);
			/* Select PLL as system clock source and configure
			the HCLK, PCLK1 and PCLK2 clocks dividers */
			RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_SYSCLK | 
			RCC_CLOCKTYPE_PCLK1 | RCC_CLOCKTYPE_PCLK2;
			RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
			RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
			RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV4;
			RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV2;
			HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_5);
}

static void I2C1_Init(void)
{



	__HAL_RCC_I2C1_CLK_ENABLE();
    
  __HAL_RCC_I2C1_FORCE_RESET();
  HAL_Delay(2);
  __HAL_RCC_I2C1_RELEASE_RESET();

  hi2c1.Instance = I2C1;
  hi2c1.Init.Timing = 0x00808CD2;
  hi2c1.Init.OwnAddress1 = 0;
  hi2c1.Init.AddressingMode = I2C_ADDRESSINGMODE_7BIT;
  hi2c1.Init.DualAddressMode = I2C_DUALADDRESS_DISABLE;
  hi2c1.Init.OwnAddress2 = 0;
  hi2c1.Init.OwnAddress2Masks = I2C_OA2_NOMASK;
  hi2c1.Init.GeneralCallMode = I2C_GENERALCALL_DISABLE;
  hi2c1.Init.NoStretchMode = I2C_NOSTRETCH_DISABLE;
  if (HAL_I2C_Init(&hi2c1) != HAL_OK)
  {
    Error_Handler();
  }

  /** Configure Analogue filter
  */
  if (HAL_I2CEx_ConfigAnalogFilter(&hi2c1, I2C_ANALOGFILTER_ENABLE) != HAL_OK)
  {
    Error_Handler();
  }

  /** Configure Digital filter
  */
  if (HAL_I2CEx_ConfigDigitalFilter(&hi2c1, 0) != HAL_OK)
  {
    Error_Handler();
  }


}

static void TIM2_Init(void)
{
  TIM_MasterConfigTypeDef sMasterConfig = {0};


  htim2.Instance = TIM2;
  htim2.Init.Prescaler = 32000;
  htim2.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim2.Init.Period = 1;
  htim2.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim2) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim2, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }


}

static void GPIO_Init(void)
{
	GPIO_InitTypeDef GPIO_InitStruct;
	
  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOB_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOH_CLK_ENABLE();
	
	GPIO_InitStruct.Pin = GPIO_PIN_8 | GPIO_PIN_9;
	GPIO_InitStruct.Mode = GPIO_MODE_AF_OD; // alternate function - open drain
	GPIO_InitStruct.Pull = GPIO_PULLUP;
	GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_VERY_HIGH;
	GPIO_InitStruct.Alternate = GPIO_AF4_I2C1;
	
	HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);
	

}

void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
	
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */

